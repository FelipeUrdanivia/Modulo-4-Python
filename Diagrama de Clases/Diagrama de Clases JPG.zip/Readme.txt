Diagrama de clases de una Escuela.
A una escuela asisten varias personas.
Estas pueden ser profesores o alumnos.
Los cursos solo existen si estos tienen alumnos.
Los profesores enseñan las materias y los alumnos las estudian.
Todos heredan atributos y metodos de la clase personas.